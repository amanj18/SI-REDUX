import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { increment, decrement } from '../actions';

export default function Counter() {
    const counter = useSelector(state => state.counter);
    const dispatch = useDispatch();

    return (
        <div>
            <h2>Counter : {counter } </h2>
            <div>
                <button className='btn btn-primary m-2 p-3' onClick={()=> dispatch(increment())}>+</button>
                <span>{counter}</span>
                <button className='btn btn-primary m-2 p-3' onClick={()=> dispatch(decrement())}>-</button>
                <button className='btn btn-danger m-2 p-3' onClick={()=> dispatch({type: 'LOGIN'})}>Login</button>
            </div>
        </div>
    )
}