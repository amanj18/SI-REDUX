import allReducers from "../reducers";
import { createStore } from "redux";


const myStore = createStore(allReducers);

export default myStore;