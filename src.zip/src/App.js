// import logo from './logo.svg';
import './App.css';
import { Provider } from 'react-redux';
import Counter from './SimpleReduxDemo/components/Counter';
import myStore from './SimpleReduxDemo/store/reduxStore';

function App() {
  return (
    <>
   <Provider  store={myStore}>
    <Counter />
    </Provider>
    <Login/>
    
    </>
      
  );
}

export default App;
